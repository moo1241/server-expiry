# Server Expiry Reminder

This repository is currently in phase 6. It contains a runnable Vue frontend, a Fastify backend, a transactional SQLite migration layer, administrator session authentication, protected server management APIs, reminder scheduling, and Telegram delivery.

## Directory structure

```text
.
|-- apps/
|   |-- backend/       # Fastify + TypeScript API
|   `-- frontend/      # Vue 3 + Vite + TypeScript + Element Plus
|-- data/              # Local SQLite files, ignored by Git
|-- .env.example
|-- package.json       # npm workspace and shared scripts
`-- README.md
```

## Requirements

- Node.js 20 LTS or newer
- npm 10 or newer

## Install dependencies

Run this from the repository root:

```bash
npm install
```

Create the backend environment file:

```bash
copy .env.example apps\backend\.env
```

PowerShell:

```powershell
Copy-Item .env.example apps/backend/.env
```

## Start development

Start both applications:

```bash
npm run dev
```

- Frontend: http://localhost:5173
- Backend health endpoint: http://localhost:3000/api/health

Start either application separately:

```bash
npm run dev:backend
npm run dev:frontend
```

Run database migrations directly when needed:

```bash
npm run db:migrate
```

The backend also runs pending migrations before it starts listening.

## Database design

The SQLite file is configured with WAL mode, full synchronous writes, foreign key enforcement, and a busy timeout. The migration runner records each migration version and SHA-256 checksum in `schema_migrations`. Every schema migration runs inside a transaction, so a failed process does not leave a partially applied migration.

The initial migration creates these tables:

- `admin_accounts` for the single administrator account used in phase 3
- `app_settings` for global settings such as the display timezone
- `servers` for server metadata, expiration timestamps, archival state, and reminder generations
- `reminder_rules` for global reminder offsets, seeded with 30, 15, 7, 3, 1, and 0 days
- `notification_plans` for per-server reminder jobs and renewal generations
- `notification_attempts` for notification delivery history, including uncertain network outcomes
- `schema_migrations` for migration versions, checksums, and UTC application times

## Administrator authentication

The second migration adds `admin_sessions`. Passwords are hashed with Node.js `scrypt`, and only SHA-256 hashes of random session tokens are stored in SQLite. The raw token is sent in an HttpOnly, SameSite=Lax cookie. Set `SESSION_COOKIE_SECURE=true` after HTTPS is enabled.

Create the single administrator account by temporarily adding these values to `apps/backend/.env`:

```env
ADMIN_USERNAME=admin
ADMIN_PASSWORD=replace-with-a-long-random-password
```

Then run:

```bash
npm run admin:create
```

Remove `ADMIN_USERNAME` and `ADMIN_PASSWORD` from the environment file after the command succeeds. The stored password hash is sufficient for later logins.

Authentication endpoints are available at `/api/auth/login`, `/api/auth/me`, and `/api/auth/logout`.

## Server management

All server endpoints require the administrator session cookie. The API accepts UTC timestamps ending in `Z` and returns `remainingSeconds` and `daysUntilExpiry` for each server.

- `GET /api/servers` lists active servers by default. Use `status=archived` or `status=all`, plus `q`, `page`, and `pageSize` for filtering and pagination.
- `GET /api/servers/:id` returns one server and its calculated remaining time.
- `POST /api/servers` creates a server and generates reminder plan rows for enabled global rules.
- `ipAddress` is optional. Empty values are preserved without blocking server creation.
- `PATCH /api/servers/:id` edits server fields. Changing the expiration time cancels pending plans and creates a new reminder generation.
- `POST /api/servers/:id/renew` updates the expiration time, cancels old plans, increments the generation, and creates new plan rows in one transaction.
- `DELETE /api/servers/:id` deletes a server and cascades its reminder plans and notification history in one transaction.

The backend settings endpoints `GET /api/settings` and `PATCH /api/settings` manage the display timezone. The default is `Asia/Shanghai`. Database timestamps remain UTC, while the frontend converts them for display and for the Chinese date-time picker.

Reminder frequency is managed through `GET /api/reminder-rules` and `PATCH /api/reminder-rules`. Each rule has an enabled flag and a `timesPerDay` value from 1 to 24. The default active rules are 7, 3, 2, 1, and 0 days before expiry. Multiple sends for one rule are distributed across the 24-hour window ending at that rule's trigger time. Updated frequencies apply when plans are created again through a new server, an expiration edit, or a renewal.

## Reminder scheduling

The third migration adds `processing_started_at_utc` so an interrupted worker can recover a claimed plan. `ReminderScheduler` runs a cron tick, claims due plans in an immediate SQLite transaction, records an attempt before calling the transport, and updates the plan and attempt history in another transaction.

Each plan is unique per server, reminder generation, and trigger offset. A successful result changes the plan to `sent`. A known failure changes it to `failed`, and an uncertain transport result changes it to `unknown`. Retryable results use exponential backoff with a maximum attempt count. A worker that stops while a plan is `processing` is recovered as an uncertain result after the processing timeout. The Telegram adapter maps HTTP failures and network uncertainty into these persisted outcomes.

When the service has been offline long enough for several reminders for one server to become overdue, the scheduler coalesces older overdue plans and sends the latest one. This avoids a burst of stale Telegram messages after recovery.

## Telegram notifications

Set `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` in the backend environment. The token is sent only to the configured Telegram Bot API endpoint and is never returned by the status endpoint. `POST /api/telegram/test` sends a manually supplied test message. `GET /api/telegram/status` reports whether Telegram is configured and whether the scheduler is enabled.

Set `REMINDER_SCHEDULER_ENABLED=true` to start the cron worker when the backend starts. A missing or partial Telegram configuration prevents the worker from starting. HTTP 4xx responses are recorded as known failures, HTTP 429 and 5xx responses are retryable failures, and network or timeout errors are recorded as uncertain outcomes.

## Build and start

```bash
npm run build
npm start
```

The frontend build is written to `apps/frontend/dist`. The backend build is written to `apps/backend/dist`. Nginx and systemd deployment are part of phase 8.

## Phase 6 acceptance

1. Run `npm install` and confirm that dependency installation succeeds.
2. Run `npm run db:migrate` and confirm it reports that migrations are already up to date.
3. Set Telegram credentials in `apps/backend/.env` and set `REMINDER_SCHEDULER_ENABLED=true`.
4. Restart the backend and confirm it remains `active`.
5. Use an authenticated request to `GET /api/telegram/status` and confirm `configured: true` and `schedulerEnabled: true`.
6. Use an authenticated request to `POST /api/telegram/test` and confirm a successful Telegram response.
7. Create a due server reminder and verify that a successful send changes the plan to `sent` and records a Telegram message id.
8. Run `npm run build` and confirm that both workspaces build successfully.
